# Suvathi Ear Killu App
Open this project in Android Studio, allow Gradle sync, then use Build > Build APK(s).
The supplied photo is already included as app/src/main/assets/your-photo.jpg.
